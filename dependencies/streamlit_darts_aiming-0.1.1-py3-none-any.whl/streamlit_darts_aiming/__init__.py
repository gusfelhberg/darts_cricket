import os
import streamlit.components.v1 as components


_RELEASE = True

if not _RELEASE:
    _component_func = components.declare_component(

        "darts",

        url="http://localhost:3001",
    )
else:

    parent_dir = os.path.dirname(os.path.abspath(__file__))
    build_dir = os.path.join(parent_dir, "frontend/build")
    _component_func = components.declare_component("darts", path=build_dir)

def aim_dart(key=None):
    component_value = _component_func(key=key, default=0)
    return component_value


if not _RELEASE:
    import streamlit as st
    import math
    import numpy as np
    from random import random

    st.subheader("Darts")


    def get_dart_score(arrow_x, arrow_y):
        # Returning values in case of not matching any of the scenarios
        # dart_score = 999
        # dart_score_mult = 0
        # distance = 0
        # comment = "Error??"

        distance = (arrow_x ** 2 + arrow_y ** 2) ** 0.5  # Pythagoras

        angle = math.degrees(math.atan2(arrow_y, arrow_x))

        if angle < 0:
            angle += 360

        ######################
        # Miss / Wire / Bull #
        ######################

        ### Miss board###
        if distance > 144:
            dart_score = 0
            dart_score_mult = 0
            comment = "Backboard!"
            return dart_score, dart_score_mult, comment

        ### Wire Shots ###        
        # wireshotbounce = 0.2
        # if np.round(distance,0) in [10,20,74,84,134,144]:
        #     if random() < wireshotbounce:
        #             dartscore = 0
        #             dartscoremult = 0
        #             comment = "Bounced!"
        #             return dartscore, dartscoremult, comment        

        wireshot_bounce = 0.2

        wire_distances = [10, 20, 74, 84, 134, 144]
        for dist in wire_distances:
            if dist - wireshot_bounce <= distance <= dist + wireshot_bounce:
                dart_score = 0
                dart_score_mult = 0
                comment = "Bounced!"
                return dart_score, dart_score_mult, comment
    
        ## wire_angles = [9, 27, 45, 63, 81, 99, 117, 135, 153, 171, 189, 207, 225, 243, 261, 279, 297, 315, 333, 351]
        wire_angles = [9*(1+2*n) for n in range(0,20)] 
        if np.round(angle, 0) in wire_angles:
            if random() < wireshot_bounce:
                dart_score = 0
                dart_score_mult = 0
                comment = "Bounced!"
                return dart_score, dart_score_mult, comment
    

        if distance < 6:
            dart_score = 25
            dart_score_mult = 2
            comment = "Double Bull!"
            return dart_score, dart_score_mult, comment

        if distance < 14:
            dart_score = 25
            dart_score_mult = 1
            comment = "Single Bull!"
            return dart_score, dart_score_mult, comment



        ######################
                # 20...1 #
        ######################

        # The original code was repeting the same logic for different angles
        # To make it simpler, all the combinations of angles (start and end)
        # and respective score number were combined in the list 'angles_distances_arrays' below
        # This way, instead of having a similar block of code for each angle range, 
        # we can have one block of code being used for each element of the array

        # A similar idea applies to the code that compares the distances to select the multiplication factor
        # The new code adds only one comparison of the distances after the code below.

        triple_distance_limit_lower = 77
        triple_distance_limit_upper = 87
        double_distance_limit_lower = 130
        double_distance_limit_upper = 140
        
        angles_distances_array = [
            #[angle_start, angle_end, score]
            [0,     9,  6],    # 6 (part 1 of 2)
            [9,    27, 13],    # 13
            [27,   45,  4],    # 4
            [45,   63, 18],    # 18
            [63,   81,  1],    # 1
            [81,   99, 20],    # 20
            [99,  117,  5],    # 5
            [117, 135, 12],    # 12
            [135, 153,  9],    # 9
            [153, 171, 14],    # 14
            [171, 189, 11],    # 11
            [189, 207,  8],    # 8
            [207, 225, 16],    # 16
            [225, 243,  7],    # 7
            [243, 261, 19],    # 19
            [261, 279,  3],    # 3
            [279, 297, 17],    # 17
            [297, 315,  2],    # 2
            [315, 333, 15],    # 15
            [333, 351, 10],    # 10
            [351, 361,  6]     # 6 (part 2 of 2)
        ] 

        for angle_start, angle_end, score in angles_distances_array:
            if angle_start <= angle < angle_end:
                    dart_score = score
                    comment = 'Hit!'

        if triple_distance_limit_lower < distance <= triple_distance_limit_upper:
            dart_score_mult = 3
        elif double_distance_limit_lower < distance <= double_distance_limit_upper:
            dart_score_mult = 2
        else:
            dart_score_mult = 1

        return dart_score, dart_score_mult, comment 




    # Create an instance of our component with a constant `name` arg, and
    # print its output value.
    x = aim_dart()
    # st.write(f'x: {x[0]} - y: {x[1]}')
    if x != 0.0:
        st.write(x)
        st.write(get_dart_score(x[0],x[1]))
        st.write(f"distance: {(x[0] ** 2 + x[1] ** 2) ** 0.5}") 
        st.write(f"angle: {math.degrees(math.atan2(x[0], x[1]))}")
        

